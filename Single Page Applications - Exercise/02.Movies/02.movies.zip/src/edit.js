import { showView } from "./utils.js";

const editSection = document.getElementById('edit-movie');

export function detailsPage(){
    showView(editSection);
}